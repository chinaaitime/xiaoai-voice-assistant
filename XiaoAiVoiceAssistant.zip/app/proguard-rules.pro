# Keep basic classes
-keepattributes *Annotation*
