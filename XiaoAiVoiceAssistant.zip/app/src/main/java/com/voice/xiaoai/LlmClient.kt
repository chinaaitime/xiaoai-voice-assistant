package com.voice.xiaoai

import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.DataOutputStream
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL

object LlmClient {

    data class ChatMessage(val role: String, val content: String)

    fun chat(
        baseUrl: String,
        apiKey: String,
        model: String,
        systemPrompt: String,
        history: List<ChatMessage>
    ): Result<String> {
        if (apiKey.isBlank()) {
            return Result.failure(IllegalStateException("请先在右上角设置中填写大模型 API Key"))
        }
        return try {
            val endpoint = "${baseUrl.trimEnd('/')}/chat/completions"
            val conn = (URL(endpoint).openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 12000
                readTimeout = 25000
                doOutput = true
                setRequestProperty("Content-Type", "application/json; charset=UTF-8")
                setRequestProperty("Authorization", "Bearer $apiKey")
            }

            val messagesArr = JSONArray()
            if (systemPrompt.isNotBlank()) {
                messagesArr.put(JSONObject().put("role", "system").put("content", systemPrompt))
            }
            for (msg in history) {
                messagesArr.put(JSONObject().put("role", msg.role).put("content", msg.content))
            }

            val payload = JSONObject()
                .put("model", model)
                .put("messages", messagesArr)
                .put("temperature", 0.7)
                .put("max_tokens", 300)

            conn.outputStream.use { os ->
                os.write(payload.toString().toByteArray(Charsets.UTF_8))
            }

            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val body = stream?.let { BufferedReader(InputStreamReader(it, Charsets.UTF_8)).readText() } ?: ""
            conn.disconnect()

            if (code !in 200..299) {
                return Result.failure(RuntimeException("接口错误($code): ${extractError(body)}"))
            }

            val json = JSONObject(body)
            val content = json.getJSONArray("choices")
                .getJSONObject(0)
                .getJSONObject("message")
                .getString("content")
                .trim()

            Result.success(content)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun transcribeWav(
        baseUrl: String,
        apiKey: String,
        model: String,
        wavBytes: ByteArray
    ): Result<String> {
        if (apiKey.isBlank()) {
            return Result.failure(IllegalStateException("云端语音识别需要填写语音 API Key"))
        }
        return try {
            val boundary = "----XiaoAiBoundary${System.currentTimeMillis()}"
            val endpoint = "${baseUrl.trimEnd('/')}/audio/transcriptions"
            val conn = (URL(endpoint).openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 10000
                readTimeout = 15000
                doOutput = true
                useCaches = false
                setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
                setRequestProperty("Authorization", "Bearer $apiKey")
            }

            DataOutputStream(conn.outputStream).use { dos ->
                // model field
                dos.writeBytes("--$boundary\r\n")
                dos.writeBytes("Content-Disposition: form-data; name=\"model\"\r\n\r\n")
                dos.write(model.toByteArray(Charsets.UTF_8))
                dos.writeBytes("\r\n")

                // file field
                dos.writeBytes("--$boundary\r\n")
                dos.writeBytes("Content-Disposition: form-data; name=\"file\"; filename=\"voice.wav\"\r\n")
                dos.writeBytes("Content-Type: audio/wav\r\n\r\n")
                dos.write(wavBytes)
                dos.writeBytes("\r\n")

                dos.writeBytes("--$boundary--\r\n")
                dos.flush()
            }

            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val body = stream?.let { BufferedReader(InputStreamReader(it, Charsets.UTF_8)).readText() } ?: ""
            conn.disconnect()

            if (code !in 200..299) {
                return Result.failure(RuntimeException("语音识别错误($code): ${extractError(body)}"))
            }

            val json = JSONObject(body)
            val text = json.optString("text", "").trim()
            Result.success(text)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun extractError(body: String): String {
        return try {
            val obj = JSONObject(body)
            obj.optJSONObject("error")?.optString("message") ?: body.take(120)
        } catch (_: Exception) {
            body.take(120)
        }
    }
}
