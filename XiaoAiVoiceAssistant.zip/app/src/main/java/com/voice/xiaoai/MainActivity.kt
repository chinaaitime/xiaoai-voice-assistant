package com.voice.xiaoai

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.concurrent.thread

class MainActivity : Activity(), VoiceEngine.Listener {

    private lateinit var orbView: CyberOrbView
    private lateinit var clockText: TextView
    private lateinit var dateText: TextView
    private lateinit var statusText: TextView
    private lateinit var badgeText: TextView
    private lateinit var chatLogText: TextView
    private lateinit var chatScroll: ScrollView
    private lateinit var talkBtn: Button

    private lateinit var voiceEngine: VoiceEngine
    private val mainHandler = Handler(Looper.getMainLooper())
    private val history = ArrayList<LlmClient.ChatMessage>()
    private val chatBuilder = StringBuilder()

    @Volatile
    private var inContinuousSession = false
    private var continuousExpireAt = 0L
    @Volatile
    private var isProcessingTurn = false

    private var systemRecognizer: SpeechRecognizer? = null

    private val clockRunnable = object : Runnable {
        override fun run() {
            val now = Date()
            clockText.text = SimpleDateFormat("HH:mm", Locale.getDefault()).format(now)
            dateText.text = SimpleDateFormat("M月d日 EEEE", Locale.CHINESE).format(now)
            if (inContinuousSession && System.currentTimeMillis() > continuousExpireAt && !isProcessingTurn) {
                inContinuousSession = false
                if (AppConfig.isWakeEnabled(this@MainActivity)) {
                    orbView.state = CyberOrbView.State.STANDBY
                    statusText.text = "待机中 · 说“${AppConfig.getWakeWord(this@MainActivity)}”唤醒"
                }
            }
            mainHandler.postDelayed(this, 1000L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        buildCyberUi()

        voiceEngine = VoiceEngine(this, this)
        voiceEngine.initTts()

        checkAndStartAudio()
    }

    private fun buildCyberUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(Color.parseColor("#05070E"))
            setPadding(28, 22, 28, 22)
        }

        // Left Pane: Clock + Cyber Orb + Status
        val leftPane = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 0.44f)
        }

        clockText = TextView(this).apply {
            textSize = 44f
            setTextColor(Color.parseColor("#E8F7FF"))
            typeface = Typeface.create("sans-serif-light", Typeface.BOLD)
            gravity = Gravity.CENTER
        }
        dateText = TextView(this).apply {
            textSize = 14f
            setTextColor(Color.parseColor("#6B8CAE"))
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 8)
        }

        orbView = CyberOrbView(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                0,
                1f
            )
            setOnClickListener { triggerManualTalk() }
        }

        statusText = TextView(this).apply {
            text = "正在初始化语音引擎..."
            textSize = 15f
            setTextColor(Color.parseColor("#00E5FF"))
            gravity = Gravity.CENTER
            setPadding(8, 4, 8, 4)
        }

        badgeText = TextView(this).apply {
            text = "AEC:-- | 1GB优化模式"
            textSize = 11f
            setTextColor(Color.parseColor("#55708E"))
            gravity = Gravity.CENTER
        }

        leftPane.addView(clockText)
        leftPane.addView(dateText)
        leftPane.addView(orbView)
        leftPane.addView(statusText)
        leftPane.addView(badgeText)

        // Right Pane: Top Controls + Chat Card + Bottom Action Bar
        val rightPane = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 0.56f).apply {
                leftMargin = 20
            }
        }

        // Top Bar
        val topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 0, 0, 12)
        }

        val titleLabel = TextView(this).apply {
            text = "XIAOAI · NEURAL CORE"
            textSize = 13f
            setTextColor(Color.parseColor("#00E5FF"))
            typeface = Typeface.MONOSPACE
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }

        val clearBtn = createNeonButton("清空", "#1A2336", "#8FA8C8") {
            history.clear()
            chatBuilder.clear()
            chatLogText.text = "对话已清空。唤醒词：${AppConfig.getWakeWord(this)}"
        }

        val settingsBtn = createNeonButton("设置 / API", "#0F2942", "#00E5FF") {
            startActivity(Intent(this, SettingsActivity::class.java))
        }.apply {
            (layoutParams as? LinearLayout.LayoutParams)?.leftMargin = 10
        }

        topBar.addView(titleLabel)
        topBar.addView(clearBtn)
        val lpSettings = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { leftMargin = 10 }
        settingsBtn.layoutParams = lpSettings
        topBar.addView(settingsBtn)

        // Chat Card
        val chatCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#0B1120"))
                cornerRadius = 22f
                setStroke(2, Color.parseColor("#1B2D48"))
            }
            setPadding(22, 18, 22, 18)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                0,
                1f
            )
        }

        chatScroll = ScrollView(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.MATCH_PARENT
            )
        }

        chatLogText = TextView(this).apply {
            textSize = 19f
            setLineSpacing(6f, 1.18f)
            setTextColor(Color.parseColor("#DCEBFF"))
            text = "欢迎使用小爱语音助手。\n\n• 首次使用请点击右上角【设置 / API】填入免费大模型 Key（支持智谱 GLM-4-Flash / 硅基流动）。\n• 说话时可直接喊“小爱同学”唤醒，播报时直接开口即可打断。"
        }
        chatScroll.addView(chatLogText)
        chatCard.addView(chatScroll)

        // Bottom Bar
        val bottomBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 12, 0, 0)
        }

        talkBtn = createNeonButton("点击直接对话 / 唤醒", "#003B5C", "#00FFA3") {
            triggerManualTalk()
        }.apply {
            layoutParams = LinearLayout.LayoutParams(0, 52.dp(), 1f)
        }

        val stopBtn = createNeonButton("打断闭麦", "#3B1325", "#FF4D79") {
            voiceEngine.stopSpeaking()
            isProcessingTurn = false
            orbView.state = CyberOrbView.State.STANDBY
            statusText.text = "已打断播报"
        }.apply {
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, 52.dp()).apply {
                leftMargin = 12
            }
        }

        bottomBar.addView(talkBtn)
        bottomBar.addView(stopBtn)

        rightPane.addView(topBar)
        rightPane.addView(chatCard)
        rightPane.addView(bottomBar)

        root.addView(leftPane)
        root.addView(rightPane)
        setContentView(root)
    }

    private fun createNeonButton(
        label: String,
        bgHex: String,
        textHex: String,
        onClick: () -> Unit
    ): Button {
        return Button(this).apply {
            text = label
            textSize = 13f
            setTextColor(Color.parseColor(textHex))
            isAllCaps = false
            background = GradientDrawable().apply {
                setColor(Color.parseColor(bgHex))
                cornerRadius = 16f
                setStroke(2, Color.parseColor(textHex))
            }
            setPadding(22, 8, 22, 8)
            setOnClickListener { onClick() }
        }
    }

    private fun Int.dp(): Int = (this * resources.displayMetrics.density).toInt()

    private fun checkAndStartAudio() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1001)
        } else {
            startEngine()
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 1001 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            startEngine()
        } else {
            statusText.text = "需要麦克风权限才能语音唤醒"
            Toast.makeText(this, "请授予麦克风权限", Toast.LENGTH_LONG).show()
        }
    }

    private fun startEngine() {
        voiceEngine.startListeningLoop()
        val wakeWord = AppConfig.getWakeWord(this)
        statusText.text = if (AppConfig.isWakeEnabled(this)) {
            "待机中 · 说“$wakeWord”唤醒"
        } else {
            "免唤醒直连监听中 · 请直接说话"
        }
    }

    private fun triggerManualTalk() {
        voiceEngine.stopSpeaking()
        inContinuousSession = true
        continuousExpireAt = System.currentTimeMillis() + AppConfig.getContinuousSec(this) * 1000L
        if (AppConfig.getAsrMode(this) == "system") {
            startSystemSpeechRecognizer()
        } else {
            voiceEngine.playWakeChime()
            orbView.state = CyberOrbView.State.LISTENING
            statusText.text = "请说话（连续对话已激活）..."
        }
    }

    private fun startSystemSpeechRecognizer() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            appendLog("系统", "当前设备未内置系统语音识别服务，请在设置中切换到【云端 Whisper/SenseVoice】模式。")
            return
        }
        voiceEngine.setPausedForSystemAsr(true)
        orbView.state = CyberOrbView.State.LISTENING
        statusText.text = "系统语音聆听中..."

        systemRecognizer?.destroy()
        systemRecognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {
                    orbView.setAudioLevel((rmsdB + 2f) * 300f)
                }
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {
                    orbView.state = CyberOrbView.State.THINKING
                }
                override fun onError(error: Int) {
                    voiceEngine.setPausedForSystemAsr(false)
                    orbView.state = CyberOrbView.State.STANDBY
                    statusText.text = "系统识别未听清($error)"
                }
                override fun onResults(results: Bundle?) {
                    voiceEngine.setPausedForSystemAsr(false)
                    val list = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    val text = list?.firstOrNull()?.trim().orEmpty()
                    if (text.isNotEmpty()) {
                        handleRecognizedText(text)
                    } else {
                        orbView.state = CyberOrbView.State.STANDBY
                    }
                }
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "zh-CN")
        }
        systemRecognizer?.startListening(intent)
    }

    override fun onAudioLevel(rms: Float) {
        mainHandler.post {
            orbView.setAudioLevel(rms)
        }
    }

    override fun onBargeInDetected() {
        mainHandler.post {
            isProcessingTurn = false
            inContinuousSession = true
            continuousExpireAt = System.currentTimeMillis() + AppConfig.getContinuousSec(this) * 1000L
            orbView.state = CyberOrbView.State.LISTENING
            statusText.text = "已打断 · 请继续说..."
        }
    }

    override fun onSpeechCaptured(wavBytes: ByteArray) {
        if (AppConfig.getAsrMode(this) == "system") {
            // In system ASR mode, VAD trigger launches system recognizer
            mainHandler.post { startSystemSpeechRecognizer() }
            return
        }
        if (isProcessingTurn) return
        isProcessingTurn = true

        mainHandler.post {
            orbView.state = CyberOrbView.State.THINKING
            statusText.text = "正在识别语音..."
        }

        thread(isDaemon = true) {
            val asrUrl = AppConfig.getAsrBaseUrl(this)
            val asrKey = AppConfig.getAsrApiKey(this).ifBlank { AppConfig.getLlmApiKey(this) }
            val asrModel = AppConfig.getAsrModel(this)

            val res = LlmClient.transcribeWav(asrUrl, asrKey, asrModel, wavBytes)
            mainHandler.post {
                res.onSuccess { text ->
                    if (text.isBlank()) {
                        isProcessingTurn = false
                        restoreStandbyStatus()
                    } else {
                        handleRecognizedText(text)
                    }
                }.onFailure { err ->
                    isProcessingTurn = false
                    orbView.state = CyberOrbView.State.STANDBY
                    statusText.text = err.message ?: "语音识别失败"
                }
            }
        }
    }

    private fun handleRecognizedText(rawText: String) {
        val text = rawText.trim()
        val wakeEnabled = AppConfig.isWakeEnabled(this)
        val wakeWord = AppConfig.getWakeWord(this)

        // Check wake word if not in continuous session
        if (wakeEnabled && !inContinuousSession) {
            val matched = isWakeWordMatch(text, wakeWord)
            if (!matched) {
                isProcessingTurn = false
                restoreStandbyStatus()
                return
            }
            inContinuousSession = true
            continuousExpireAt = System.currentTimeMillis() + AppConfig.getContinuousSec(this) * 1000L
            val remainder = stripWakeWord(text, wakeWord)
            if (remainder.isBlank()) {
                isProcessingTurn = false
                voiceEngine.playWakeChime()
                appendLog("我", text)
                appendLog(wakeWord, "我在，请说。")
                voiceEngine.speak("我在")
                return
            } else {
                voiceEngine.playWakeChime()
                queryLlm(remainder)
                return
            }
        }

        // Already awake or wake-word disabled
        inContinuousSession = true
        continuousExpireAt = System.currentTimeMillis() + AppConfig.getContinuousSec(this) * 1000L
        queryLlm(text)
    }

    private fun isWakeWordMatch(text: String, wakeWord: String): Boolean {
        val clean = text.replace(Regex("[\\s，。！？,.!?]"), "")
        if (clean.contains(wakeWord)) return true
        if (wakeWord == "小爱同学") {
            return clean.contains("小爱") || clean.contains("小艾") || clean.contains("晓爱")
        }
        return false
    }

    private fun stripWakeWord(text: String, wakeWord: String): String {
        return text.replace(wakeWord, "")
            .replace("小爱同学", "")
            .replace("小爱", "")
            .trim(' ', '，', '。', '！', '？', ',', '.', '!', '?')
    }

    private fun queryLlm(userText: String) {
        isProcessingTurn = true
        appendLog("我", userText)
        orbView.state = CyberOrbView.State.THINKING
        statusText.text = "大模型思考中..."

        history.add(LlmClient.ChatMessage("user", userText))
        while (history.size > 12) history.removeAt(0)

        thread(isDaemon = true) {
            val res = LlmClient.chat(
                baseUrl = AppConfig.getLlmBaseUrl(this),
                apiKey = AppConfig.getLlmApiKey(this),
                model = AppConfig.getLlmModel(this),
                systemPrompt = AppConfig.getSystemPrompt(this),
                history = history.toList()
            )
            mainHandler.post {
                isProcessingTurn = false
                res.onSuccess { reply ->
                    history.add(LlmClient.ChatMessage("assistant", reply))
                    appendLog(AppConfig.getWakeWord(this), reply)
                    continuousExpireAt = System.currentTimeMillis() + AppConfig.getContinuousSec(this) * 1000L
                    voiceEngine.speak(reply)
                }.onFailure { err ->
                    val msg = err.message ?: "请求失败"
                    appendLog("错误", msg)
                    orbView.state = CyberOrbView.State.STANDBY
                    statusText.text = msg
                }
            }
        }
    }

    override fun onTtsStart() {
        mainHandler.post {
            orbView.state = CyberOrbView.State.SPEAKING
            statusText.text = if (AppConfig.isBargeInEnabled(this)) {
                "播报中 · 随时说话可打断"
            } else {
                "正在播报..."
            }
        }
    }

    override fun onTtsDone() {
        mainHandler.post {
            continuousExpireAt = System.currentTimeMillis() + AppConfig.getContinuousSec(this) * 1000L
            restoreStandbyStatus()
        }
    }

    private fun restoreStandbyStatus() {
        if (inContinuousSession) {
            orbView.state = CyberOrbView.State.LISTENING
            statusText.text = "连续对话中 · 请直接说话..."
        } else {
            orbView.state = CyberOrbView.State.STANDBY
            statusText.text = if (AppConfig.isWakeEnabled(this)) {
                "待机中 · 说“${AppConfig.getWakeWord(this)}”唤醒"
            } else {
                "直连聆听中..."
            }
        }
    }

    override fun onEngineStatus(aecEnabled: Boolean, nsEnabled: Boolean, ttsReady: Boolean) {
        mainHandler.post {
            val aecStr = if (aecEnabled) "硬件AEC" else "软件阈值"
            val ttsStr = if (ttsReady) "TTS就绪" else "TTS未就绪"
            badgeText.text = "$aecStr · $ttsStr · ${AppConfig.getLlmModel(this)}"
        }
    }

    override fun onError(message: String) {
        mainHandler.post {
            statusText.text = message
        }
    }

    private fun appendLog(speaker: String, content: String) {
        if (chatBuilder.length > 3000) {
            chatBuilder.delete(0, chatBuilder.length - 1500)
        }
        if (chatBuilder.isNotEmpty()) chatBuilder.append("\n\n")
        chatBuilder.append("【").append(speaker).append("】").append(content)
        chatLogText.text = chatBuilder.toString()
        chatScroll.post { chatScroll.fullScroll(View.FOCUS_DOWN) }
    }

    override fun onResume() {
        super.onResume()
        mainHandler.post(clockRunnable)
        badgeText.text = "模型: ${AppConfig.getLlmModel(this)}"
    }

    override fun onPause() {
        super.onPause()
        mainHandler.removeCallbacks(clockRunnable)
    }

    override fun onDestroy() {
        super.onDestroy()
        systemRecognizer?.destroy()
        voiceEngine.destroy()
    }
}
