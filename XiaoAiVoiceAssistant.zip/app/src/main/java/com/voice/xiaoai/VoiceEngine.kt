package com.voice.xiaoai

import android.content.Context
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.MediaRecorder
import android.media.ToneGenerator
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.NoiseSuppressor
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.Locale
import kotlin.concurrent.thread
import kotlin.math.sqrt

class VoiceEngine(
    private val context: Context,
    private val listener: Listener
) {
    interface Listener {
        fun onAudioLevel(rms: Float)
        fun onSpeechCaptured(wavBytes: ByteArray)
        fun onBargeInDetected()
        fun onTtsStart()
        fun onTtsDone()
        fun onEngineStatus(aecEnabled: Boolean, nsEnabled: Boolean, ttsReady: Boolean)
        fun onError(message: String)
    }

    companion object {
        private const val SAMPLE_RATE = 16000
        private const val CHANNEL_CONFIG = AudioFormat.CHANNEL_IN_MONO
        private const val AUDIO_FORMAT = AudioFormat.ENCODING_PCM_16BIT
        private const val SILENCE_TIMEOUT_MS = 950L
        private const val MAX_RECORD_MS = 10000L
        private const val MIN_SPEECH_MS = 350L
    }

    @Volatile
    private var running = false
    @Volatile
    private var isSpeakingTts = false
    @Volatile
    private var isPausedForSystemAsr = false

    private var audioRecord: AudioRecord? = null
    private var aec: AcousticEchoCanceler? = null
    private var ns: NoiseSuppressor? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var aecActive = false
    private var nsActive = false

    fun initTts() {
        tts = TextToSpeech(context.applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val res = tts?.setLanguage(Locale.SIMPLIFIED_CHINESE)
                ttsReady = res != TextToSpeech.LANG_MISSING_DATA && res != TextToSpeech.LANG_NOT_SUPPORTED
                if (!ttsReady) {
                    tts?.setLanguage(Locale.CHINESE)
                    ttsReady = true
                }
                tts?.setSpeechRate(1.05f)
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {
                        isSpeakingTts = true
                        listener.onTtsStart()
                    }

                    override fun onDone(utteranceId: String?) {
                        isSpeakingTts = false
                        listener.onTtsDone()
                    }

                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {
                        isSpeakingTts = false
                        listener.onTtsDone()
                    }
                })
            } else {
                ttsReady = false
            }
            listener.onEngineStatus(aecActive, nsActive, ttsReady)
        }
    }

    fun speak(text: String) {
        if (!ttsReady) {
            listener.onTtsDone()
            return
        }
        val params = Bundle().apply {
            putInt(TextToSpeech.Engine.KEY_PARAM_STREAM, AudioManager.STREAM_MUSIC)
        }
        isSpeakingTts = true
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, params, "xiaoai_${System.currentTimeMillis()}")
    }

    fun stopSpeaking() {
        isSpeakingTts = false
        tts?.stop()
    }

    fun playWakeChime() {
        try {
            val tg = ToneGenerator(AudioManager.STREAM_MUSIC, 75)
            tg.startTone(ToneGenerator.TONE_PROP_ACK, 160)
            thread {
                Thread.sleep(220)
                tg.release()
            }
        } catch (_: Exception) {
        }
    }

    fun setPausedForSystemAsr(paused: Boolean) {
        isPausedForSystemAsr = paused
    }

    fun startListeningLoop() {
        if (running) return
        running = true
        thread(name = "XiaoAiAudioLoop", isDaemon = true) {
            runCaptureLoop()
        }
    }

    fun stopListeningLoop() {
        running = false
        releaseAudioRecord()
    }

    fun destroy() {
        stopListeningLoop()
        stopSpeaking()
        tts?.shutdown()
        tts = null
    }

    private fun releaseAudioRecord() {
        try {
            aec?.release()
            ns?.release()
            audioRecord?.stop()
            audioRecord?.release()
        } catch (_: Exception) {
        }
        aec = null
        ns = null
        audioRecord = null
    }

    private fun runCaptureLoop() {
        val minBuf = AudioRecord.getMinBufferSize(SAMPLE_RATE, CHANNEL_CONFIG, AUDIO_FORMAT)
        if (minBuf <= 0) {
            listener.onError("无法初始化麦克风缓冲区")
            running = false
            return
        }
        val bufSize = (minBuf * 2).coerceAtLeast(3200)
        // VOICE_COMMUNICATION enables hardware echo cancellation on Android 8.1 smart speakers
        val record = try {
            AudioRecord(
                MediaRecorder.AudioSource.VOICE_COMMUNICATION,
                SAMPLE_RATE,
                CHANNEL_CONFIG,
                AUDIO_FORMAT,
                bufSize
            )
        } catch (e: SecurityException) {
            listener.onError("缺少录音权限")
            running = false
            return
        }

        if (record.state != AudioRecord.STATE_INITIALIZED) {
            listener.onError("麦克风初始化失败")
            running = false
            return
        }
        audioRecord = record

        val sessionId = record.audioSessionId
        if (AcousticEchoCanceler.isAvailable()) {
            aec = AcousticEchoCanceler.create(sessionId)?.apply { enabled = true }
            aecActive = aec?.enabled == true
        }
        if (NoiseSuppressor.isAvailable()) {
            ns = NoiseSuppressor.create(sessionId)?.apply { enabled = true }
            nsActive = ns?.enabled == true
        }
        listener.onEngineStatus(aecActive, nsActive, ttsReady)

        record.startRecording()

        val chunkShorts = ShortArray(1600) // 100ms chunks at 16kHz
        val pcmBuffer = ByteArrayOutputStream(64000)
        val preRollBuffer = ArrayDeque<ByteArray>(5) // Keep 400ms pre-roll before trigger

        var capturingSpeech = false
        var speechStartTime = 0L
        var lastVoiceTime = 0L
        var bargeInStreak = 0

        while (running) {
            if (isPausedForSystemAsr) {
                Thread.sleep(80)
                continue
            }

            val readCount = record.read(chunkShorts, 0, chunkShorts.size)
            if (readCount <= 0) {
                Thread.sleep(20)
                continue
            }

            val rms = computeRms(chunkShorts, readCount)
            listener.onAudioLevel(rms)

            val chunkBytes = shortsToBytes(chunkShorts, readCount)
            val now = System.currentTimeMillis()

            // Handle Barge-In while TTS is speaking
            if (isSpeakingTts) {
                val bargeInEnabled = AppConfig.isBargeInEnabled(context)
                val bargeInThreshold = AppConfig.getBargeInThreshold(context)
                if (bargeInEnabled && rms >= bargeInThreshold) {
                    bargeInStreak++
                    if (bargeInStreak >= 2) { // ~200ms sustained loud voice to avoid speaker pop
                        bargeInStreak = 0
                        stopSpeaking()
                        listener.onBargeInDetected()
                        capturingSpeech = true
                        speechStartTime = now
                        lastVoiceTime = now
                        pcmBuffer.reset()
                        for (pre in preRollBuffer) pcmBuffer.write(pre)
                        pcmBuffer.write(chunkBytes)
                    }
                } else {
                    bargeInStreak = 0
                }
                updatePreRoll(preRollBuffer, chunkBytes)
                continue
            }

            val vadThreshold = AppConfig.getVadThreshold(context)

            if (!capturingSpeech) {
                updatePreRoll(preRollBuffer, chunkBytes)
                if (rms >= vadThreshold) {
                    capturingSpeech = true
                    speechStartTime = now
                    lastVoiceTime = now
                    pcmBuffer.reset()
                    for (pre in preRollBuffer) pcmBuffer.write(pre)
                    pcmBuffer.write(chunkBytes)
                }
            } else {
                pcmBuffer.write(chunkBytes)
                if (rms >= vadThreshold * 0.75f) {
                    lastVoiceTime = now
                }
                val elapsed = now - speechStartTime
                val silentFor = now - lastVoiceTime
                if (silentFor >= SILENCE_TIMEOUT_MS || elapsed >= MAX_RECORD_MS) {
                    capturingSpeech = false
                    val duration = lastVoiceTime - speechStartTime
                    if (duration >= MIN_SPEECH_MS && pcmBuffer.size() > 3200) {
                        val wav = encodeWav(pcmBuffer.toByteArray(), SAMPLE_RATE, 1, 16)
                        listener.onSpeechCaptured(wav)
                    }
                    pcmBuffer.reset()
                }
            }
        }

        releaseAudioRecord()
    }

    private fun updatePreRoll(queue: ArrayDeque<ByteArray>, chunk: ByteArray) {
        if (queue.size >= 4) queue.removeFirst()
        queue.addLast(chunk)
    }

    private fun computeRms(samples: ShortArray, count: Int): Float {
        var sum = 0.0
        for (i in 0 until count) {
            val s = samples[i].toDouble()
            sum += s * s
        }
        return sqrt(sum / count).toFloat()
    }

    private fun shortsToBytes(samples: ShortArray, count: Int): ByteArray {
        val bb = ByteBuffer.allocate(count * 2).order(ByteOrder.LITTLE_ENDIAN)
        for (i in 0 until count) bb.putShort(samples[i])
        return bb.array()
    }

    private fun encodeWav(pcm: ByteArray, sampleRate: Int, channels: Int, bitsPerSample: Int): ByteArray {
        val byteRate = sampleRate * channels * bitsPerSample / 8
        val totalDataLen = pcm.size + 36
        val out = ByteArrayOutputStream(pcm.size + 44)
        val header = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
        header.put("RIFF".toByteArray(Charsets.US_ASCII))
        header.putInt(totalDataLen)
        header.put("WAVE".toByteArray(Charsets.US_ASCII))
        header.put("fmt ".toByteArray(Charsets.US_ASCII))
        header.putInt(16) // PCM chunk size
        header.putShort(1) // AudioFormat = PCM
        header.putShort(channels.toShort())
        header.putInt(sampleRate)
        header.putInt(byteRate)
        header.putShort((channels * bitsPerSample / 8).toShort())
        header.putShort(bitsPerSample.toShort())
        header.put("data".toByteArray(Charsets.US_ASCII))
        header.putInt(pcm.size)
        out.write(header.array())
        out.write(pcm)
        return out.toByteArray()
    }
}
