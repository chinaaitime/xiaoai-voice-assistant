package com.voice.xiaoai

import android.content.Context

object AppConfig {
    private const val PREF_NAME = "xiaoai_voice_prefs"

    // LLM Settings
    const val KEY_LLM_BASE_URL = "llm_base_url"
    const val KEY_LLM_API_KEY = "llm_api_key"
    const val KEY_LLM_MODEL = "llm_model"
    const val KEY_SYSTEM_PROMPT = "system_prompt"

    // ASR Settings (Cloud Whisper/SenseVoice vs System)
    const val KEY_ASR_MODE = "asr_mode" // "cloud" or "system"
    const val KEY_ASR_BASE_URL = "asr_base_url"
    const val KEY_ASR_API_KEY = "asr_api_key"
    const val KEY_ASR_MODEL = "asr_model"

    // Voice Wake-up & Barge-in Settings
    const val KEY_WAKE_WORD = "wake_word"
    const val KEY_WAKE_ENABLED = "wake_enabled"
    const val KEY_BARGE_IN_ENABLED = "barge_in_enabled"
    const val KEY_VAD_THRESHOLD = "vad_threshold"
    const val KEY_BARGE_IN_THRESHOLD = "barge_in_threshold"
    const val KEY_CONTINUOUS_SEC = "continuous_sec"

    // Free Preset Constants
    const val PRESET_ZHIPU_URL = "https://open.bigmodel.cn/api/paas/v4"
    const val PRESET_ZHIPU_MODEL = "glm-4-flash-250414"

    const val PRESET_SILICON_URL = "https://api.siliconflow.cn/v1"
    const val PRESET_SILICON_LLM_MODEL = "Qwen/Qwen2.5-7B-Instruct"
    const val PRESET_SILICON_ASR_MODEL = "FunAudioLLM/SenseVoiceSmall"

    private fun prefs(ctx: Context) = ctx.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)

    fun getLlmBaseUrl(ctx: Context): String =
        prefs(ctx).getString(KEY_LLM_BASE_URL, PRESET_ZHIPU_URL) ?: PRESET_ZHIPU_URL

    fun getLlmApiKey(ctx: Context): String =
        prefs(ctx).getString(KEY_LLM_API_KEY, "") ?: ""

    fun getLlmModel(ctx: Context): String =
        prefs(ctx).getString(KEY_LLM_MODEL, PRESET_ZHIPU_MODEL) ?: PRESET_ZHIPU_MODEL

    fun getSystemPrompt(ctx: Context): String =
        prefs(ctx).getString(
            KEY_SYSTEM_PROMPT,
            "你是运行在桌面智能音箱上的语音助手“小爱同学”。请用自然、口语化、简洁的中文回答，每次回复尽量控制在80字以内，适合语音直接播报，不要使用Markdown符号或星号。"
        ) ?: ""

    fun getAsrMode(ctx: Context): String =
        prefs(ctx).getString(KEY_ASR_MODE, "cloud") ?: "cloud"

    fun getAsrBaseUrl(ctx: Context): String =
        prefs(ctx).getString(KEY_ASR_BASE_URL, PRESET_SILICON_URL) ?: PRESET_SILICON_URL

    fun getAsrApiKey(ctx: Context): String =
        prefs(ctx).getString(KEY_ASR_API_KEY, "") ?: ""

    fun getAsrModel(ctx: Context): String =
        prefs(ctx).getString(KEY_ASR_MODEL, PRESET_SILICON_ASR_MODEL) ?: PRESET_SILICON_ASR_MODEL

    fun getWakeWord(ctx: Context): String =
        prefs(ctx).getString(KEY_WAKE_WORD, "小爱同学") ?: "小爱同学"

    fun isWakeEnabled(ctx: Context): Boolean =
        prefs(ctx).getBoolean(KEY_WAKE_ENABLED, true)

    fun isBargeInEnabled(ctx: Context): Boolean =
        prefs(ctx).getBoolean(KEY_BARGE_IN_ENABLED, true)

    fun getVadThreshold(ctx: Context): Int =
        prefs(ctx).getInt(KEY_VAD_THRESHOLD, 900)

    fun getBargeInThreshold(ctx: Context): Int =
        prefs(ctx).getInt(KEY_BARGE_IN_THRESHOLD, 2600)

    fun getContinuousSec(ctx: Context): Int =
        prefs(ctx).getInt(KEY_CONTINUOUS_SEC, 25)

    fun saveAll(
        ctx: Context,
        llmBaseUrl: String,
        llmApiKey: String,
        llmModel: String,
        systemPrompt: String,
        asrMode: String,
        asrBaseUrl: String,
        asrApiKey: String,
        asrModel: String,
        wakeWord: String,
        wakeEnabled: Boolean,
        bargeInEnabled: Boolean,
        vadThreshold: Int,
        bargeInThreshold: Int,
        continuousSec: Int
    ) {
        prefs(ctx).edit()
            .putString(KEY_LLM_BASE_URL, llmBaseUrl.trim().trimEnd('/'))
            .putString(KEY_LLM_API_KEY, llmApiKey.trim())
            .putString(KEY_LLM_MODEL, llmModel.trim())
            .putString(KEY_SYSTEM_PROMPT, systemPrompt.trim())
            .putString(KEY_ASR_MODE, asrMode)
            .putString(KEY_ASR_BASE_URL, asrBaseUrl.trim().trimEnd('/'))
            .putString(KEY_ASR_API_KEY, asrApiKey.trim())
            .putString(KEY_ASR_MODEL, asrModel.trim())
            .putString(KEY_WAKE_WORD, wakeWord.trim().ifEmpty { "小爱同学" })
            .putBoolean(KEY_WAKE_ENABLED, wakeEnabled)
            .putBoolean(KEY_BARGE_IN_ENABLED, bargeInEnabled)
            .putInt(KEY_VAD_THRESHOLD, vadThreshold.coerceIn(200, 5000))
            .putInt(KEY_BARGE_IN_THRESHOLD, bargeInThreshold.coerceIn(500, 10000))
            .putInt(KEY_CONTINUOUS_SEC, continuousSec.coerceIn(5, 120))
            .apply()
    }
}
