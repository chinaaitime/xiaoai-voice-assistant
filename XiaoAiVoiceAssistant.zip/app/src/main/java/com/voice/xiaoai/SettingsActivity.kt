package com.voice.xiaoai

import android.app.Activity
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class SettingsActivity : Activity() {

    private lateinit var llmUrlInput: EditText
    private lateinit var llmKeyInput: EditText
    private lateinit var llmModelInput: EditText
    private lateinit var sysPromptInput: EditText

    private lateinit var asrCloudRadio: RadioButton
    private lateinit var asrSystemRadio: RadioButton
    private lateinit var asrUrlInput: EditText
    private lateinit var asrKeyInput: EditText
    private lateinit var asrModelInput: EditText

    private lateinit var wakeWordInput: EditText
    private lateinit var wakeCheck: CheckBox
    private lateinit var bargeInCheck: CheckBox
    private lateinit var vadInput: EditText
    private lateinit var bargeInInput: EditText
    private lateinit var continuousInput: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val scroll = ScrollView(this).apply {
            setBackgroundColor(Color.parseColor("#070B14"))
            setPadding(36, 24, 36, 24)
        }

        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }

        // Header
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 0, 0, 16)
        }
        val title = TextView(this).apply {
            text = "语音助手设置（适配京鱼座 i8 Pro）"
            textSize = 20f
            setTextColor(Color.parseColor("#00E5FF"))
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val saveBtn = actionBtn("保存并返回", "#003B5C", "#00FFA3") { saveAndClose() }
        val backBtn = actionBtn("取消", "#232B3E", "#AABBCC") { finish() }.apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { leftMargin = 12 }
        }
        header.addView(title)
        header.addView(backBtn)
        header.addView(saveBtn)
        container.addView(header)

        // Free Preset Buttons
        val presetRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, 0, 0, 16)
        }
        val zhipuBtn = actionBtn("一键填入：智谱免费 GLM-4-Flash", "#112947", "#00E5FF") {
            llmUrlInput.setText(AppConfig.PRESET_ZHIPU_URL)
            llmModelInput.setText(AppConfig.PRESET_ZHIPU_MODEL)
            Toast.makeText(this, "已切换为智谱免费接口，请填入智谱 API Key", Toast.LENGTH_SHORT).show()
        }
        val siliconBtn = actionBtn("一键填入：硅基流动免费(对话+语音)", "#1B2242", "#B388FF") {
            llmUrlInput.setText(AppConfig.PRESET_SILICON_URL)
            llmModelInput.setText(AppConfig.PRESET_SILICON_LLM_MODEL)
            asrUrlInput.setText(AppConfig.PRESET_SILICON_URL)
            asrModelInput.setText(AppConfig.PRESET_SILICON_ASR_MODEL)
            asrCloudRadio.isChecked = true
            Toast.makeText(this, "已切换为硅基流动免费接口，填入硅基 Key 即可同时用于对话和语音识别", Toast.LENGTH_SHORT).show()
        }.apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { leftMargin = 14 }
        }
        presetRow.addView(zhipuBtn)
        presetRow.addView(siliconBtn)
        container.addView(presetRow)

        // Section 1: LLM
        container.addView(sectionTitle("1. 大模型后端配置（OpenAI 兼容格式）"))
        llmUrlInput = addField(container, "Base URL", AppConfig.getLlmBaseUrl(this))
        llmKeyInput = addField(container, "API Key（必填）", AppConfig.getLlmApiKey(this), password = true)
        llmModelInput = addField(container, "模型名称", AppConfig.getLlmModel(this))
        sysPromptInput = addField(container, "系统人设提示词", AppConfig.getSystemPrompt(this))

        // Section 2: ASR
        container.addView(sectionTitle("2. 语音识别（ASR）配置"))
        val radioGroup = RadioGroup(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, 4, 0, 8)
        }
        asrCloudRadio = RadioButton(this).apply {
            text = "云端免费 SenseVoice/Whisper（推荐，不依赖系统引擎）"
            setTextColor(Color.WHITE)
        }
        asrSystemRadio = RadioButton(this).apply {
            text = "手机系统自带语音识别"
            setTextColor(Color.WHITE)
        }
        radioGroup.addView(asrCloudRadio)
        radioGroup.addView(asrSystemRadio)
        if (AppConfig.getAsrMode(this) == "system") asrSystemRadio.isChecked = true else asrCloudRadio.isChecked = true
        container.addView(radioGroup)

        asrUrlInput = addField(container, "语音识别 Base URL", AppConfig.getAsrBaseUrl(this))
        asrKeyInput = addField(container, "语音 API Key（留空则复用上方大模型 Key）", AppConfig.getAsrApiKey(this), password = true)
        asrModelInput = addField(container, "语音识别模型", AppConfig.getAsrModel(this))

        // Section 3: Wake word & Barge-in
        container.addView(sectionTitle("3. 唤醒词与对话打断"))
        wakeCheck = CheckBox(this).apply {
            text = "开启语音唤醒词过滤（关闭则直接说话就能对话）"
            isChecked = AppConfig.isWakeEnabled(this@SettingsActivity)
            setTextColor(Color.WHITE)
        }
        bargeInCheck = CheckBox(this).apply {
            text = "开启播报时说话打断（Barge-in）"
            isChecked = AppConfig.isBargeInEnabled(this@SettingsActivity)
            setTextColor(Color.WHITE)
        }
        container.addView(wakeCheck)
        container.addView(bargeInCheck)

        wakeWordInput = addField(container, "唤醒词", AppConfig.getWakeWord(this))
        vadInput = addField(container, "说话触发音量阈值（越小越灵敏，默认900）", AppConfig.getVadThreshold(this).toString(), number = true)
        bargeInInput = addField(container, "打断音量阈值（防喇叭回声误触，默认2600）", AppConfig.getBargeInThreshold(this).toString(), number = true)
        continuousInput = addField(container, "唤醒后免再次唤醒的连续对话秒数（默认25）", AppConfig.getContinuousSec(this).toString(), number = true)

        scroll.addView(container)
        setContentView(scroll)
    }

    private fun sectionTitle(text: String): TextView {
        return TextView(this).apply {
            this.text = text
            textSize = 16f
            setTextColor(Color.parseColor("#00FFA3"))
            setPadding(0, 18, 0, 8)
        }
    }

    private fun addField(
        parent: LinearLayout,
        label: String,
        initial: String,
        password: Boolean = false,
        number: Boolean = false
    ): EditText {
        val lbl = TextView(this).apply {
            text = label
            textSize = 13f
            setTextColor(Color.parseColor("#90A4AE"))
            setPadding(0, 6, 0, 4)
        }
        val et = EditText(this).apply {
            setText(initial)
            textSize = 15f
            setTextColor(Color.WHITE)
            setHintTextColor(Color.GRAY)
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#11192A"))
                cornerRadius = 10f
                setStroke(1, Color.parseColor("#2A3B5C"))
            }
            setPadding(16, 12, 16, 12)
            if (password) {
                inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
            } else if (number) {
                inputType = InputType.TYPE_CLASS_NUMBER
            }
        }
        parent.addView(lbl)
        parent.addView(et)
        return et
    }

    private fun actionBtn(label: String, bgHex: String, textHex: String, onClick: () -> Unit): Button {
        return Button(this).apply {
            text = label
            textSize = 13f
            isAllCaps = false
            setTextColor(Color.parseColor(textHex))
            background = GradientDrawable().apply {
                setColor(Color.parseColor(bgHex))
                cornerRadius = 12f
                setStroke(2, Color.parseColor(textHex))
            }
            setPadding(20, 8, 20, 8)
            setOnClickListener { onClick() }
        }
    }

    private fun saveAndClose() {
        AppConfig.saveAll(
            ctx = this,
            llmBaseUrl = llmUrlInput.text.toString(),
            llmApiKey = llmKeyInput.text.toString(),
            llmModel = llmModelInput.text.toString(),
            systemPrompt = sysPromptInput.text.toString(),
            asrMode = if (asrSystemRadio.isChecked) "system" else "cloud",
            asrBaseUrl = asrUrlInput.text.toString(),
            asrApiKey = asrKeyInput.text.toString(),
            asrModel = asrModelInput.text.toString(),
            wakeWord = wakeWordInput.text.toString(),
            wakeEnabled = wakeCheck.isChecked,
            bargeInEnabled = bargeInCheck.isChecked,
            vadThreshold = vadInput.text.toString().toIntOrNull() ?: 900,
            bargeInThreshold = bargeInInput.text.toString().toIntOrNull() ?: 2600,
            continuousSec = continuousInput.text.toString().toIntOrNull() ?: 25
        )
        Toast.makeText(this, "设置已保存", Toast.LENGTH_SHORT).show()
        finish()
    }
}
