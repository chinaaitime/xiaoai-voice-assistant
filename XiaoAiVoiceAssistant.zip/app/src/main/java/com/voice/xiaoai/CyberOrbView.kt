package com.voice.xiaoai

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.graphics.SweepGradient
import android.util.AttributeSet
import android.view.View
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

class CyberOrbView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    enum class State {
        STANDBY,    // Waiting for wake word
        LISTENING,  // Recording user speech
        THINKING,   // Waiting for LLM response
        SPEAKING    // TTS speaking (barge-in active)
    }

    var state: State = State.STANDBY
        set(value) {
            field = value
            updateShaders()
            invalidate()
        }

    private var targetLevel = 0f
    private var smoothLevel = 0f
    private var phase = 0f
    private var lastFrameTime = System.nanoTime()

    private val bgGlowPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val wavePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 4f
        strokeCap = Paint.Cap.ROUND
    }
    private val particlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }
    private val corePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }

    private val barCount = 48
    private val barAngles = FloatArray(barCount) { (it * 2f * PI.toFloat()) / barCount }

    private var cx = 0f
    private var cy = 0f
    private var baseRadius = 100f

    fun setAudioLevel(rms: Float) {
        // Normalize 0..1
        targetLevel = (rms / 3500f).coerceIn(0f, 1f)
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        cx = w / 2f
        cy = h / 2f
        baseRadius = min(w, h) * 0.27f
        updateShaders()
    }

    private fun updateShaders() {
        if (cx == 0f || cy == 0f) return
        val (c1, c2, c3) = when (state) {
            State.STANDBY -> Triple(
                Color.parseColor("#00E5FF"),
                Color.parseColor("#2979FF"),
                Color.parseColor("#00B8D4")
            )
            State.LISTENING -> Triple(
                Color.parseColor("#00FFA3"),
                Color.parseColor("#00E5FF"),
                Color.parseColor("#1DE9B6")
            )
            State.THINKING -> Triple(
                Color.parseColor("#AA00FF"),
                Color.parseColor("#00E5FF"),
                Color.parseColor("#D500F9")
            )
            State.SPEAKING -> Triple(
                Color.parseColor("#FF9100"),
                Color.parseColor("#FF1744"),
                Color.parseColor("#FFD600")
            )
        }

        bgGlowPaint.shader = RadialGradient(
            cx, cy, baseRadius * 2.1f,
            intArrayOf(
                Color.argb(95, Color.red(c1), Color.green(c1), Color.blue(c1)),
                Color.argb(25, Color.red(c2), Color.green(c2), Color.blue(c2)),
                Color.TRANSPARENT
            ),
            floatArrayOf(0.25f, 0.65f, 1f),
            Shader.TileMode.CLAMP
        )

        ringPaint.shader = SweepGradient(
            cx, cy,
            intArrayOf(c1, c2, c3, c1),
            null
        )

        corePaint.shader = RadialGradient(
            cx, cy, baseRadius * 0.72f,
            intArrayOf(
                Color.argb(180, Color.red(c1), Color.green(c1), Color.blue(c1)),
                Color.argb(40, Color.red(c2), Color.green(c2), Color.blue(c2)),
                Color.TRANSPARENT
            ),
            floatArrayOf(0f, 0.7f, 1f),
            Shader.TileMode.CLAMP
        )

        wavePaint.color = c1
        particlePaint.color = c3
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val now = System.nanoTime()
        val dt = ((now - lastFrameTime) / 1_000_000_000f).coerceIn(0.001f, 0.05f)
        lastFrameTime = now

        val speed = when (state) {
            State.STANDBY -> 0.9f
            State.LISTENING -> 2.2f
            State.THINKING -> 4.8f
            State.SPEAKING -> 2.8f
        }
        phase = (phase + dt * speed) % (2f * PI.toFloat() * 100f)
        smoothLevel += (targetLevel - smoothLevel) * 0.25f

        val breath = sin(phase * 1.4f) * 0.04f
        val dynamicBoost = when (state) {
            State.LISTENING -> smoothLevel * 0.28f
            State.SPEAKING -> (0.10f + 0.14f * sin(phase * 4.5f) * cos(phase * 2.1f))
            State.THINKING -> 0.06f * sin(phase * 3f)
            State.STANDBY -> smoothLevel * 0.08f
        }
        val r = baseRadius * (1f + breath + dynamicBoost)

        // 1. Ambient radial glow
        canvas.drawCircle(cx, cy, baseRadius * 2.1f, bgGlowPaint)

        // 2. Inner energy core
        canvas.drawCircle(cx, cy, r * 0.72f, corePaint)

        // 3. Outer rotating neon ring
        canvas.save()
        canvas.rotate(Math.toDegrees(phase.toDouble()).toFloat() * 18f, cx, cy)
        ringPaint.strokeWidth = 10f
        ringPaint.alpha = 230
        canvas.drawCircle(cx, cy, r, ringPaint)

        // Secondary dashed/thin ring
        ringPaint.strokeWidth = 3f
        ringPaint.alpha = 130
        canvas.drawCircle(cx, cy, r * 1.18f, ringPaint)
        canvas.restore()

        // 4. Radial audio spectrum bars
        val ampScale = when (state) {
            State.LISTENING -> 14f + smoothLevel * 55f
            State.SPEAKING -> 18f + 22f * kotlin.math.abs(sin(phase * 3.2f))
            State.THINKING -> 12f
            State.STANDBY -> 6f + smoothLevel * 18f
        }
        for (i in 0 until barCount) {
            val angle = barAngles[i] + phase * 0.35f
            val wave = 0.5f + 0.5f * sin(i * 0.75f + phase * 3.5f)
            val len = 6f + wave * ampScale
            val innerR = r * 1.03f
            val outerR = innerR + len
            val cosA = cos(angle)
            val sinA = sin(angle)
            wavePaint.alpha = (110 + (wave * 145).toInt()).coerceIn(0, 255)
            canvas.drawLine(
                cx + innerR * cosA, cy + innerR * sinA,
                cx + outerR * cosA, cy + outerR * sinA,
                wavePaint
            )
        }

        // 5. Orbiting neon particles (6 lightweight dots)
        for (p in 0 until 6) {
            val a = phase * (0.6f + p * 0.12f) + p * 1.047f
            val orbitR = r * (1.28f + 0.08f * sin(phase + p))
            particlePaint.alpha = 180
            canvas.drawCircle(
                cx + orbitR * cos(a),
                cy + orbitR * sin(a),
                4f + (p % 2) * 2f,
                particlePaint
            )
        }

        // Keep 60fps smooth animation
        postInvalidateOnAnimation()
    }
}
